「流し雛オンライン」README.txt

【概要】
このプログラムは2021年9月7日から9月10日にかけて開催されたハッカソン、
"StarT-Tech(https://sites.google.com/view/start-tech2021/%E3%83%9B%E3%83%BC%E3%83%A0)"
のチーム愛犬天使による作品として制作されました。

願い事を入力すると、その内容（文字コード）に応じた見た目の流し雛が、
Twitter(https://twitter.com/ngsbn_online)に投稿されます。

【使い方】
「はじめる」ボタンを押した後に表示されるテキストボックスに願い事を書いたのち、
「流す」ボタンを押すと流し雛がツイートされます。

その後、「みんなの流し雛」を押すと流し雛オンラインのTwitterに遷移します。
「終了」ボタンを押すと終了します。

【動作環境】
Windows 64bitのみ(Win10で動作確認済み)


【注意点】
・投稿できる願い事の最大文字数は116文字です。
・公序良俗に反する内容の願い事の投稿はご遠慮ください。
・ツール等を用いた過度な連投はご遠慮ください。

【作者】
・Hibiki(https://twitter.com/Yukijika)
・けんちゃん(https://twitter.com/kensei_hykw)
・てんし。(https://twitter.com/TakashiNotAngel)
(総領息子〔https://twitter.com/taka104n0〕)

【クレジット】
BGM・効果音: OtoLogic様(https://otologic.jp/)
流し雛素材: みさき様(http://www.misaki.rdy.jp/illust/)

(※著作権はソフト作者、素材の作者様に帰属します。)